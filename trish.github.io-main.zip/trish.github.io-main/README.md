# trish.github.io
<html>
  <body>
    <a href="https://en.wikipedia.org/wiki/Affenpinscher" for more info></a>
    <h1>Affenpinscher(Dog breed)</h1>
    <p>Affenpinschers are generally healthy dogs, and responsible breeders.</p>
    <h2>Appearance</h2>
    <p>Affenpinscher dressed in black, gray, silver, black and tan, or red, which ranges from brownish to an orangey tan. Some red Affenpinschers have black, brown, or white hair mixed in with the red, along with tan furnishings, and some black Affenpinschers have a few white or silver hairs mixed in.Life span :12 to 14 yrs.</p>
   <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/Affenpinscher.jpg/220px-Affenpinscher.jpg">
    <table>
            <thead>
                <tr>
                    <th>COLOR</th>
                    <th>LIFE SPAN</th>
                    <th>HEIGHT</th>
                </tr>
            </thead>
      <tbody>
                <tr>
                    <td>Black, Tan, Grey, Silver, Belge, Red</td>
                    <td>12 – 14 years</td>
                    <td>23 – 30 cm</td>
        </tr>
            </tbody>
      </table>
     <a href="https://en.wikipedia.org/wiki/Affenpinscher" for more info></a>
     </body>
     </html>
     
